export const inside = [
	{
		name : 'sample Inside 1',
		image: 'inside/inside-1.jpg'
		
	}, {
		name: 'sample Inside 2',
		image: 'inside/inside-2.jpg'
		
		
	}, {
		name: 'sample Inside 3',
		image: 'inside/inside-3.jpg'
		

	}, {
		name: 'sample Inside 4',
		image: 'inside/inside-4.jpg'
		

	}, {
		name: 'sample Inside 5',
		image: 'inside/inside-5.jpg'
		

	}, {
		name: 'sample Inside 6',
		image: 'inside/inside-6.jpg'
		

	}, {
		name: 'sample Inside 7',
		image: 'inside/inside-7.jpg'
		

	}, {
		name: 'sample Inside 8',
		image: 'inside/inside-8.jpg'
		

	}, {
		name: 'sample Inside 9',
		image: 'inside/inside-9.jpg'
		
	
	}, {
		name: 'sample Inside 10',
		image: 'inside/inside-10.jpg'
		
		
	}, {
		name: 'sample Inside 11',
		image: 'inside/inside-11.jpg'
		

	}, {
		name: 'sample Inside 12',
		image: 'inside/inside-12.jpg'
		

	}, {
		name: 'sample Inside 13',
		image: 'inside/inside-13.jpg'
		

	}, {
		name: 'sample Inside 14',
		image: 'inside/inside-14.jpg'
		

	}, {
		name: 'sample Inside 15',
		image: 'inside/inside-15.jpg'
		

	}, {
		name: 'sample Inside 16',
		image: 'inside/inside-16.jpg'
		

	}, {
		name: 'sample Inside 17',
		image: 'inside/inside-17.jpg'
	
	
	}, {
		name: 'sample Inside 18',
		image: 'inside/inside-18.jpg'
		
		
	}, {
		name: 'sample Inside 19',
		image: 'inside/inside-19.jpg'
		

	}, {
		name: 'sample Inside 20',
		image: 'inside/inside-20.jpg'
		

	}, {
		name: 'sample Inside 21',
		image: 'inside/inside-21.jpg'
		

	}, {
		name: 'sample Inside 22',
		image: 'inside/inside-22.jpg'
		

	}, {
		name: 'sample Inside 23',
		image: 'inside/inside-23.jpg'
		

	}, {
		name: 'sample Inside 24',
		image: 'inside/inside-24.jpg'
		

	}, {
		name: 'sample Inside 25',
		image: 'inside/inside-25.jpg'


	}, {
		name: 'sample Inside 26',
		image: 'inside/inside-26.jpg'
		
		
	}, {
		name: 'sample Inside 27',
		image: 'inside/inside-27.jpg'
		

	}, {
		name: 'sample Inside 28',
		image: 'inside/inside-28.jpg'
		

	}, {
		name: 'sample Inside 29',
		image: 'inside/inside-29.jpg'
		

	}, {
		name: 'sample Inside 30',
		image: 'inside/inside-30.jpg'
		

	}, {
		name: 'sample Inside 31',
		image: 'inside/inside-31.jpg'
		

	}, {
		name: 'sample Inside 32',
		image: 'inside/inside-32.jpg'
		

	}, {
		name: 'sample Inside 33',
		image: 'inside/inside-33.jpg'


	}, {
		name: 'sample Inside 34',
		image: 'inside/inside-34.jpg'
		
		
	}, {
		name: 'sample Inside 35',
		image: 'inside/inside-35.jpg'
		

	}, {
		name: 'sample Inside 36',
		image: 'inside/inside-36.jpg'
		

	}, {
		name: 'sample Inside 37',
		image: 'inside/inside-37.jpg'
		

	}, {
		name: 'sample Inside 38',
		image: 'inside/inside-38.jpg'
		

	}, {
		name: 'sample Inside 39',
		image: 'inside/inside-39.jpg'
		

	}, {
		name: 'sample Inside 40',
		image: 'inside/inside-40.jpg'
		

	}, {
		name: 'sample Inside 41',
		image: 'inside/inside-41.jpg'


	}, {
		name: 'sample Inside 42',
		image: 'inside/inside-42.jpg'
		
		
	}, {
		name: 'sample Inside 43',
		image: 'inside/inside-43.jpg'
		

	}, {
		name: 'sample Inside 44',
		image: 'inside/inside-44.jpg'
		

	}, {
		name: 'sample Inside 45',
		image: 'inside/inside-45.jpg'
		

	}, {
		name: 'sample Inside 46',
		image: 'inside/inside-46.jpg'
		

	}, {
		name: 'sample Inside 47',
		image: 'inside/inside-47.jpg'
		

	}, {
		name: 'sample Inside 48',
		image: 'inside/inside-48.jpg'
		

	}, {
		name: 'sample Inside 49',
		image: 'inside/inside-49.jpg'

	}, {
		name: 'sample Inside 50',
		image: 'inside/inside-50.jpg'
		
		
	}, {
		name: 'sample Inside 51',
		image: 'inside/inside-51.jpg'
		

	}, {
		name: 'sample Inside 52',
		image: 'inside/inside-52.jpg'

		
	}, {
		name: 'sample Inside 53',
		image: 'inside/inside-53.jpg'
		

	}, {
		name: 'sample Inside 54',
		image: 'inside/inside-54.jpg'
		

	}, {
		name: 'sample Inside 55',
		image: 'inside/inside-55.jpg'

	}, {
		name: 'sample Inside 56',
		image: 'inside/inside-56.jpg'
		
		
	}
];