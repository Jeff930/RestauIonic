export const outside = [
	{
		name : 'sample Outside 1',
		image: 'outside/outside-1.jpg'
		
	}, {
		name: 'sample Outside 2',
		image: 'outside/outside-2.jpg'
		
		
	}, {
		name: 'sample Outside 3',
		image: 'outside/outside-3.jpg'
		

	}, {
		name: 'sample Outside 4',
		image: 'outside/outside-4.jpg'
		

	}, {
		name: 'sample Outside 5',
		image: 'outside/outside-5.jpg'
		

	}, {
		name: 'sample Outside 6',
		image: 'outside/outside-6.jpg'
		
	}
];