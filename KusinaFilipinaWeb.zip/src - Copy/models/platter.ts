export const platters = [
	{
		name : 'Grilled Meat Platter',
		description : '4 BBQ Pork, 4 BBQ Chicken, Inihaw na Manok, Inihaw na Liempo, Ensaladang Talong',
		image: 'platter/GrilledMeatPlatter.jpg',
		price : '44.99'
		
	},{
		name : 'Fried Meat Platter',
		description : 'Crispy Pata, Lechon Kawali, Fried Chicken, Chicharon Bulaklak,Lumpiang Shanghai, Mango Salsa',
		image: 'platter/FriedMeatPlatter.jpg',
		price : '49.99'
		
	},{
		name : 'Grilled Seafood Platter',
		description : 'Garlic Prawn,Pinaputok na bangus or Pampano,Squid, Mussels, Ensaladang Talong',
		image: 'platter/GrilledSeafoodPlatter.jpg',
		price : '49.99'
		
	},{
		name : 'Appetizer Platter',
		description : 'Egg Rolls, Calamari, Fries, Fried Oyster',
		image: 'platter/AppetizerPlatter.jpg',
		price : '29.99'
		
	}
];