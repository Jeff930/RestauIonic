export const food = [
	{
		name : 'sample Food 1',
		image: 'food/food-1.jpg',
		price: '2200',
	}, {
		name: 'sample Food 2',
		image: 'food/food-2.jpg',
		price: '2200',
		
	}, {
		name: 'sample Food 3',
		image: 'food/food-3.jpg',
		price: '2200',

	}, {
		name: 'sample Food 4',
		image: 'food/food-4.jpg',
		price: '2200',

	}, {
		name: 'sample Food 5',
		image: 'food/food-5.jpg',
		price: '2200',

	}, {
		name: 'sample Food 6',
		image: 'food/food-6.jpg',
		price: '2200',

	}, {
		name: 'sample Food 7',
		image: 'food/food-7.jpg',
		price: '2200',

	}, {
		name: 'sample Food 9',
		image: 'food/food-9.jpg',
		price: '2200',

	}, {
		name: 'sample Food 10',
		image: 'food/food-10.jpg',
		price: '2200',
		
	}, {
		name: 'sample Food 11',
		image: 'food/food-11.jpg',
		price: '2200',

	}, {
		name: 'sample Food 12',
		image: 'food/food-12.jpg',
		price: '2200',

	}, {
		name: 'sample Food 13',
		image: 'food/food-13.jpg',
		price: '2200',

	}, {
		name: 'sample Food 14',
		image: 'food/food-14.jpg',
		price: '2200',

	}, {
		name: 'sample Food 15',
		image: 'food/food-15.jpg',
		price: '2200',

	}, {
		name: 'sample Food 16',
		image: 'food/food-16.jpg',
		price: '2200',

	}, {
		name: 'sample Food 17',
		image: 'food/food-17.jpg',
		price: '2200',
	
	}, {
		name: 'sample Food 18',
		image: 'food/food-18.jpg',
		price: '2200',
		
	}, {
		name: 'sample Food 19',
		image: 'food/food-19.jpg',
		price: '2200',

	}, {
		name: 'sample Food 20',
		image: 'food/food-20.jpg',
		price: '2200',

	}, {
		name: 'sample Food 21',
		image: 'food/food-21.jpg',
		price: '2200',

	}, {
		name: 'sample Food 22',
		image: 'food/food-22.jpg',
		price: '2200',

	}, {
		name: 'sample Food 23',
		image: 'food/food-23.jpg',
		price: '2200',

	}, {
		name: 'sample Food 24',
		image: 'food/food-24.jpg',
		price: '2200',

	}, {
		name: 'sample Food 25',
		image: 'food/food-25.jpg',
		price: '2200',
	
	}, {
		name: 'sample Food 26',
		image: 'food/food-26.jpg',
		price: '2200',
		
	}, {
		name: 'sample Food 27',
		image: 'food/food-27.jpg',
		price: '2200',

	}, {
		name: 'sample Food 28',
		image: 'food/food-28.jpg',
		price: '2200',

	}, {
		name: 'sample Food 29',
		image: 'food/food-29.jpg',
		price: '2200',

	}, {
		name: 'sample Food 30',
		image: 'food/food-30.jpg',
		price: '2200',

	}, {
		name: 'sample Food 31',
		image: 'food/food-31.jpg',
		price: '2200',

	}, {
		name: 'sample Food 32',
		image: 'food/food-32.jpg',
		price: '2200',

	}, {
		name: 'sample Food 33',
		image: 'food/food-33.jpg',
		price: '2200',

	}, {
		name: 'sample Food 34',
		image: 'food/food-34.jpg',
		price: '2200',
		
	}, {
		name: 'sample Food 35',
		image: 'food/food-35.jpg',
		price: '2200',

	}, {
		name: 'sample Food 36',
		image: 'food/food-36.jpg',
		price: '2200',

	}, {
		name: 'sample Food 37',
		image: 'food/food-37.jpg',
		price: '2200',

	}, {
		name: 'sample Food 38',
		image: 'food/food-38.jpg',
		price: '2200',

	}, {
		name: 'sample Food 39',
		image: 'food/food-39.jpg',
		price: '2200',

	}, {
		name: 'sample Food 40',
		image: 'food/food-40.jpg',
		price: '2200',

	}, {
		name: 'sample Food 41',
		image: 'food/food-41.jpg',
		price: '2200',

	}, {
		name: 'sample Food 42',
		image: 'food/food-42.jpg',
		price: '2200',
		
	}, {
		name: 'sample Food 43',
		image: 'food/food-43.jpg',
		price: '2200',

	}, {
		name: 'sample Food 44',
		image: 'food/food-44.jpg',
		price: '2200',

	}, {
		name: 'sample Food 45',
		image: 'food/food-45.jpg',
		price: '2200',

	}, {
		name: 'sample Food 46',
		image: 'food/food-46.jpg',
		price: '2200',

	}, {
		name: 'sample Food 47',
		image: 'food/food-47.jpg',
		price: '2200',

	}, {
		name: 'sample Food 48',
		image: 'food/food-48.jpg',
		price: '2200',

	}, {
		name: 'sample Food 49',
		image: 'food/food-49.jpg',
		price: '2200',

	}, {
		name: 'sample Food 50',
		image: 'food/food-50.jpg',
		price: '2200',
		
	}, {
		name: 'sample Food 51',
		image: 'food/food-51.jpg',
		price: '2200',

	}, {
		name: 'sample Food 52',
		image: 'food/food-52.jpg',
		price: '2200',

	}, {
		name: 'sample Food 53',
		image: 'food/food-53.jpg',
		price: '2200',

	}, {
		name: 'sample Food 54',
		image: 'food/food-54.jpg',
		price: '2200',

	}, {
		name: 'sample Food 55',
		image: 'food/food-55.jpg',
		price: '2200',

	}, {
		name: 'sample Food 56',
		image: 'food/food-56.jpg',
		price: '2200',

	}, {
		name: 'sample Food 57',
		image: 'food/food-57.jpg',
		price: '2200',

	}, {
		name: 'sample Food 58',
		image: 'food/food-58.jpg',
		price: '2200',
		
	}, {
		name: 'sample Food 59',
		image: 'food/food-59.jpg',
		price: '2200',

	}, {
		name: 'sample Food 60',
		image: 'food/food-60.jpg',
		price: '2200',

	}, {
		name: 'sample Food 61',
		image: 'food/food-61.jpg',
		price: '2200',

	}, {
		name: 'sample Food 62',
		image: 'food/food-62.jpg',
		price: '2200',

	}, {
		name: 'sample Food 63',
		image: 'food/food-63.jpg',
		price: '2200',

	}, {
		name: 'sample Food 64',
		image: 'food/food-64.jpg',
		price: '2200',

	}, {
		name: 'sample Food 65',
		image: 'food/food-65.jpg',
		price: '2200',

	}, {
		name: 'sample Food 66',
		image: 'food/food-66.jpg',
		price: '2200',
		
	}, {
		name: 'sample Food 67',
		image: 'food/food-67.jpg',
		price: '2200',

	}, {
		name: 'sample Food 68',
		image: 'food/food-68.jpg',
		price: '2200',

	}, {
		name: 'sample Food 69',
		image: 'food/food-69.jpg',
		price: '2200',

	}, {
		name: 'sample Food 70',
		image: 'food/food-70.jpg',
		price: '2200',

	}, {
		name: 'sample Food 71',
		image: 'food/food-71.jpg',
		price: '2200',

	}, {
		name: 'sample Food 72',
		image: 'food/food-72.jpg',
		price: '2200',

	}, {
		name: 'sample Food 73',
		image: 'food/food-73.jpg',
		price: '2200',

	}, {
		name: 'sample Food 74',
		image: 'food/food-74.jpg',
		price: '2200',
		
	}, {
		name: 'sample Food 75',
		image: 'food/food-75.jpg',
		price: '2200',

	}, {
		name: 'sample Food 76',
		image: 'food/food-76.jpg',
		price: '2200',

	}, {
		name: 'sample Food 77',
		image: 'food/food-78.jpg',
		price: '2200',

	}, {
		name: 'sample Food 78',
		image: 'food/food-78.jpg',
		price: '2200',

	}, {
		name: 'sample Food 79',
		image: 'food/food-79.jpg',
		price: '2200',

	}, {
		name: 'sample Food 80',
		image: 'food/food-80.jpg',
		price: '2200',

	}, {
		name: 'sample Food 81',
		image: 'food/food-81.jpg',
		price: '2200',

	}, {
		name: 'sample Food 82',
		image: 'food/food-82.jpg',
		price: '2200',
		
	}, {
		name: 'sample Food 83',
		image: 'food/food-83.jpg',
		price: '2200',

	}, {
		name: 'sample Food 84',
		image: 'food/food-84.jpg',
		price: '2200',

	}, {
		name: 'sample Food 85',
		image: 'food/food-85.jpg',
		price: '2200',

	}, {
		name: 'sample Food 86',
		image: 'food/food-86.jpg',
		price: '2200',

	}, {
		name: 'sample Food 87',
		image: 'food/food-87.jpg',
		price: '2200',

	}, {
		name: 'sample Food 88',
		image: 'food/food-88.jpg',
		price: '2200',

	}, {
		name: 'sample Food 89',
		image: 'food/food-89.jpg',
		price: '2200',
	
	}, {
		name: 'sample Food 90',
		image: 'food/food-90.jpg',
		price: '2200',

	}, {
		name: 'sample Food 91',
		image: 'food/food-91.jpg',
		price: '2200',

	}, {
		name: 'sample Food 92',
		image: 'food/food-92.jpg',
		price: '2200',
		
	}, {
		name: 'sample Food 93',
		image: 'food/food-93.jpg',
		price: '2200',

	}, {
		name: 'sample Food 94',
		image: 'food/food-94.jpg',
		price: '2200',

	}, {
		name: 'sample Food 95',
		image: 'food/food-95.jpg',
		price: '2200',

	}, {
		name: 'sample Food 96',
		image: 'food/food-96.jpg',
		price: '2200',

	}, {
		name: 'sample Food 97',
		image: 'food/food-97.jpg',
		price: '2200',

	}, {
		name: 'sample Food 98',
		image: 'food/food-98.jpg',
		price: '2200',

	}, {
		name: 'sample Food 99',
		image: 'food/food-99.jpg',
		price: '2200',

	}, {
		name: 'sample Food 100',
		image: 'food/food-100.jpg',
		price: '2200',

	}, {
		name: 'sample Food 101',
		image: 'food/food-101.jpg',
		price: '2200',

	}, {
		name: 'sample Food 102',
		image: 'food/food-102.jpg',
		price: '2200',
		
	}, {
		name: 'sample Food 103',
		image: 'food/food-103.jpg',
		price: '2200',

	}, {
		name: 'sample Food 104',
		image: 'food/food-104.jpg',
		price: '2200',

	}, {
		name: 'sample Food 105',
		image: 'food/food-105.jpg',
		price: '2200',

	}, {
		name: 'sample Food 106',
		image: 'food/food-106.jpg',
		price: '2200',

	}, {
		name: 'sample Food 107',
		image: 'food/food-107.jpg',
		price: '2200',

	}, {
		name: 'sample Food 108',
		image: 'food/food-108.jpg',
		price: '2200',

	}, {
		name: 'sample Food 109',
		image: 'food/food-109.jpg',
		price: '2200',

	}, {
		name: 'sample Food 110',
		image: 'food/food-110.jpg',
		price: '2200',

	}, {
		name: 'sample Food 111',
		image: 'food/food-111.jpg',
		price: '2200',

	}, {
		name: 'sample Food 112',
		image: 'food/food-112.jpg',
		price: '2200',
		
	}, {
		name: 'sample Food 113',
		image: 'food/food-113.jpg',
		price: '2200',

	}, {
		name: 'sample Food 114',
		image: 'food/food-114.jpg',
		price: '2200',

	}, {
		name: 'sample Food 115',
		image: 'food/food-115.jpg',
		price: '2200',

	},{
		name: 'sample Food 117',
		image: 'food/food-117.jpg',
		price: '2200',

	}, {
		name: 'sample Food 118',
		image: 'food/food-118.jpg',
		price: '2200',

	}, {
		name: 'sample Food 119',
		image: 'food/food-119.jpg',
		price: '2200',

	}, {
		name: 'sample Food 120',
		image: 'food/food-120.jpg',
		price: '2200',

	}, {
		name: 'sample Food 121',
		image: 'food/food-121.jpg',
		price: '2200',

	}, {
		name: 'sample Food 122',
		image: 'food/food-122.jpg',
		price: '2200',
		
	}, {
		name: 'sample Food 123',
		image: 'food/food-123.jpg',
		price: '2200',

	}, {
		name: 'sample Food 124',
		image: 'food/food-124.jpg',
		price: '2200',

	}, {
		name: 'sample Food 125',
		image: 'food/food-125.jpg',
		price: '2200',

	}, {
		name: 'sample Food 126',
		image: 'food/food-126.jpg',
		price: '2200',

	}, {
		name: 'sample Food 127',
		image: 'food/food-127.jpg',
		price: '2200',

	}, {
		name: 'sample Food 128',
		image: 'food/food-128.jpg',
		price: '2200',

	}, {
		name: 'sample Food 129',
		image: 'food/food-129.jpg',
		price: '2200',

	}, {
		name: 'sample Food 130',
		image: 'food/food-130.jpg',
		price: '2200',

	}, {
		name: 'sample Food 131',
		image: 'food/food-131.jpg',
		price: '2200',

	}, {
		name: 'sample Food 132',
		image: 'food/food-132.jpg',
		price: '2200',
		
	}, {
		name: 'sample Food 133',
		image: 'food/food-133.jpg',
		price: '2200',

	}, {
		name: 'sample Food 134',
		image: 'food/food-134.jpg',
		price: '2200',

	}, {
		name: 'sample Food 135',
		image: 'food/food-135.jpg',
		price: '2200',

	}, {
		name: 'sample Food 136',
		image: 'food/food-136.jpg',
		price: '2200',

	}, {
		name: 'sample Food 137',
		image: 'food/food-137.jpg',
		price: '2200',

	}, {
		name: 'sample Food 138',
		image: 'food/food-138.jpg',
		price: '2200',

	}, {
		name: 'sample Food 139',
		image: 'food/food-139.jpg',
		price: '2200',

	}, {
		name: 'sample Food 140',
		image: 'food/food-140.jpg',
		price: '2200',

	}, {
		name: 'sample Food 141',
		image: 'food/food-141.jpg',
		price: '2200',

	}, {
		name: 'sample Food 142',
		image: 'food/food-142.jpg',
		price: '2200',
		
	}, {
		name: 'sample Food 143',
		image: 'food/food-143.jpg',
		price: '2200',

	}, {
		name: 'sample Food 144',
		image: 'food/food-144.jpg',
		price: '2200',

	}, {
		name: 'sample Food 145',
		image: 'food/food-145.jpg',
		price: '2200',

	}, {
		name: 'sample Food 146',
		image: 'food/food-146.jpg',
		price: '2200',

	}, {
		name: 'sample Food 147',
		image: 'food/food-147.jpg',
		price: '2200',

	}, {
		name: 'sample Food 148',
		image: 'food/food-148.jpg',
		price: '2200',

	}, {
		name: 'sample Food 149',
		image: 'food/food-149.jpg',
		price: '2200',
	
	}, {
		name: 'sample Food 150',
		image: 'food/food-150.jpg',
		price: '2200',

	}, {
		name: 'sample Food 151',
		image: 'food/food-151.jpg',
		price: '2200',

	}, {
		name: 'sample Food 152',
		image: 'food/food-152.jpg',
		price: '2200',
		
	}, {
		name: 'sample Food 153',
		image: 'food/food-153.jpg',
		price: '2200',

	}, {
		name: 'sample Food 154',
		image: 'food/food-154.jpg',
		price: '2200',

	}, {
		name: 'sample Food 155',
		image: 'food/food-155.jpg',
		price: '2200',

	}, {
		name: 'sample Food 156',
		image: 'food/food-156.jpg',
		price: '2200',

	}, {
		name: 'sample Food 157',
		image: 'food/food-157.jpg',
		price: '2200',

	}, {
		name: 'sample Food 158',
		image: 'food/food-158.jpg',
		price: '2200',

	}, {
		name: 'sample Food 159',
		image: 'food/food-159.jpg',
		price: '2200',
	
	}, {
		name: 'sample Food 160',
		image: 'food/food-160.jpg',
		price: '2200',

	}, {
		name: 'sample Food 161',
		image: 'food/food-161.jpg',
		price: '2200',

	}, {
		name: 'sample Food 162',
		image: 'food/food-162.jpg',
		price: '2200',
		
	}, {
		name: 'sample Food 163',
		image: 'food/food-163.jpg',
		price: '2200',

	}, {
		name: 'sample Food 164',
		image: 'food/food-164.jpg',
		price: '2200',

	}, {
		name: 'sample Food 165',
		image: 'food/food-165.jpg',
		price: '2200',

	}, {
		name: 'sample Food 166',
		image: 'food/food-166.jpg',
		price: '2200',

	}, {
		name: 'sample Food 167',
		image: 'food/food-167.jpg',
		price: '2200',

	}, {
		name: 'sample Food 168',
		image: 'food/food-168.jpg',
		price: '2200',

	}, {
		name: 'sample Food 169',
		image: 'food/food-169.jpg',
		price: '2200',
	
	}, {
		name: 'sample Food 170',
		image: 'food/food-170.jpg',
		price: '2200',

	}, {
		name: 'sample Food 171',
		image: 'food/food-171.jpg',
		price: '2200',

	}, {
		name: 'sample Food 172',
		image: 'food/food-172.jpg',
		price: '2200',
		
	}, {
		name: 'sample Food 173',
		image: 'food/food-173.jpg',
		price: '2200',

	}, {
		name: 'sample Food 174',
		image: 'food/food-174.jpg',
		price: '2200',

	}, {
		name: 'sample Food 175',
		image: 'food/food-175.jpg',
		price: '2200',

	}, {
		name: 'sample Food 176',
		image: 'food/food-176.jpg',
		price: '2200',

	}, {
		name: 'sample Food 177',
		image: 'food/food-177.jpg',
		price: '2200',

	}, {
		name: 'sample Food 178',
		image: 'food/food-178.jpg',
		price: '2200',

	}, {
		name: 'sample Food 179',
		image: 'food/food-179.jpg',
		price: '2200',
	
	}, {
		name: 'sample Food 180',
		image: 'food/food-180.jpg',
		price: '2200',

	}, {
		name: 'sample Food 181',
		image: 'food/food-181.jpg',
		price: '2200',

	}, {
		name: 'sample Food 182',
		image: 'food/food-182.jpg',
		price: '2200',
		
	}, {
		name: 'sample Food 183',
		image: 'food/food-183.jpg',
		price: '2200',

	}, {
		name: 'sample Food 184',
		image: 'food/food-184.jpg',
		price: '2200',

	}, {
		name: 'sample Food 185',
		image: 'food/food-185.jpg',
		price: '2200',

	}, {
		name: 'sample Food 186',
		image: 'food/food-186.jpg',
		price: '2200',

	}, {
		name: 'sample Food 187',
		image: 'food/food-187.jpg',
		price: '2200',

	}, {
		name: 'sample Food 188',
		image: 'food/food-188.jpg',
		price: '2200',

	}, {
		name: 'sample Food 189',
		image: 'food/food-189.jpg',
		price: '2200',
	
	}, {
		name: 'sample Food 190',
		image: 'food/food-190.jpg',
		price: '2200',

	}, {
		name: 'sample Food 191',
		image: 'food/food-191.jpg',
		price: '2200',

	}, {
		name: 'sample Food 192',
		image: 'food/food-192.jpg',
		price: '2200',
		
	}, {
		name: 'sample Food 193',
		image: 'food/food-193.jpg',
		price: '2200',

	}, {
		name: 'sample Food 194',
		image: 'food/food-194.jpg',
		price: '2200',

	}, {
		name: 'sample Food 195',
		image: 'food/food-195.jpg',
		price: '2200',

	}, {
		name: 'sample Food 196',
		image: 'food/food-196.jpg',
		price: '2200',

	}, {
		name: 'sample Food 197',
		image: 'food/food-197.jpg',
		price: '2200',

	}, {
		name: 'sample Food 198',
		image: 'food/food-198.jpg',
		price: '2200',

	}, {
		name: 'sample Food 199',
		image: 'food/food-199.jpg',
		price: '2200',
	
	}, {
		name: 'sample Food 200',
		image: 'food/food-200.jpg',
		price: '2200',

	}, {
		name: 'sample Food 201',
		image: 'food/food-201.jpg',
		price: '2200',

	}, {
		name: 'sample Food 202',
		image: 'food/food-202.jpg',
		price: '2200',
		
	}, {
		name: 'sample Food 203',
		image: 'food/food-203.jpg',
		price: '2200',

	}, {
		name: 'sample Food 204',
		image: 'food/food-204.jpg',
		price: '2200',

	}, {
		name: 'sample Food 205',
		image: 'food/food-205.jpg',
		price: '2200',

	}, {
		name: 'sample Food 206',
		image: 'food/food-206.jpg',
		price: '2200',

	}, {
		name: 'sample Food 207',
		image: 'food/food-207.jpg',
		price: '2200',

	}, {
		name: 'sample Food 208',
		image: 'food/food-208.jpg',
		price: '2200',

	}, {
		name: 'sample Food 209',
		image: 'food/food-209.jpg',
		price: '2200',
	
	}, {
		name: 'sample Food 210',
		image: 'food/food-210.jpg',
		price: '2200',

	}, {
		name: 'sample Food 211',
		image: 'food/food-211.jpg',
		price: '2200',

	}, {
		name: 'sample Food 212',
		image: 'food/food-212.jpg',
		price: '2200',
		
	}, {
		name: 'sample Food 213',
		image: 'food/food-213.jpg',
		price: '2200',

	}, {
		name: 'sample Food 214',
		image: 'food/food-214.jpg',
		price: '2200',

	}, {
		name: 'sample Food 215',
		image: 'food/food-215.jpg',
		price: '2200',

	}, {
		name: 'sample Food 216',
		image: 'food/food-216.jpg',
		price: '2200',

	}, {
		name: 'sample Food 217',
		image: 'food/food-217.jpg',
		price: '2200',

	}, {
		name: 'sample Food 218',
		image: 'food/food-218.jpg',
		price: '2200',

	}, {
		name: 'sample Food 219',
		image: 'food/food-219.jpg',
		price: '2200',
	
	}, {
		name: 'sample Food 220',
		image: 'food/food-220.jpg',
		price: '2200',

	}, {
		name: 'sample Food 221',
		image: 'food/food-221.jpg',
		price: '2200',

	}, {
		name: 'sample Food 222',
		image: 'food/food-222.jpg',
		price: '2200',
		
	}, {
		name: 'sample Food 223',
		image: 'food/food-223.jpg',
		price: '2200',

	}, {
		name: 'sample Food 224',
		image: 'food/food-224.jpg',
		price: '2200',

	}, {
		name: 'sample Food 225',
		image: 'food/food-225.jpg',
		price: '2200',

	}, {
		name: 'sample Food 226',
		image: 'food/food-226.jpg',
		price: '2200',

	}, {
		name: 'sample Food 227',
		image: 'food/food-227.jpg',
		price: '2200',

	}, {
		name: 'sample Food 228',
		image: 'food/food-228.jpg',
		price: '2200',

	}, {
		name: 'sample Food 229',
		image: 'food/food-229.jpg',
		price: '2200',
	
	}, {
		name: 'sample Food 230',
		image: 'food/food-230.jpg',
		price: '2200',

	}, {
		name: 'sample Food 231',
		image: 'food/food-231.jpg',
		price: '2200',

	}, {
		name: 'sample Food 232',
		image: 'food/food-232.jpg',
		price: '2200',
		
	}, {
		name: 'sample Food 233',
		image: 'food/food-233.jpg',
		price: '2200',

	}, {
		name: 'sample Food 234',
		image: 'food/food-234.jpg',
		price: '2200',

	}, {
		name: 'sample Food 235',
		image: 'food/food-235.jpg',
		price: '2200',

	}, {
		name: 'sample Food 236',
		image: 'food/food-206.jpg',
		price: '2200',

	}, {
		name: 'sample Food 237',
		image: 'food/food-207.jpg',
		price: '2200',

	}, {
		name: 'sample Food 238',
		image: 'food/food-238.jpg',
		price: '2200',

	}, {
		name: 'sample Food 239',
		image: 'food/food-239.jpg',
		price: '2200',
	
	}, {
		name: 'sample Food 240',
		image: 'food/food-240.jpg',
		price: '2200',

	}, {
		name: 'sample Food 241',
		image: 'food/food-241.jpg',
		price: '2200',

	}, {
		name: 'sample Food 242',
		image: 'food/food-242.jpg',
		price: '2200',
		
	}, {
		name: 'sample Food 243',
		image: 'food/food-243.jpg',
		price: '2200',

	}, {
		name: 'sample Food 244',
		image: 'food/food-244.jpg',
		price: '2200',

	}, {
		name: 'sample Food 245',
		image: 'food/food-245.jpg',
		price: '2200',

	}, {
		name: 'sample Food 246',
		image: 'food/food-246.jpg',
		price: '2200',

	}, {
		name: 'sample Food 247',
		image: 'food/food-247.jpg',
		price: '2200',

	}, {
		name: 'sample Food 248',
		image: 'food/food-248.jpg',
		price: '2200',

	}, {
		name: 'sample Food 249',
		image: 'food/food-249.jpg',
		price: '2200',
	
	}, {
		name: 'sample Food 250',
		image: 'food/food-250.jpg',
		price: '2200',

	}, {
		name: 'sample Food 251',
		image: 'food/food-251.jpg',
		price: '2200',

	}, {
		name: 'sample Food 252',
		image: 'food/food-252.jpg',
		price: '2200',
		
	}, {
		name: 'sample Food 253',
		image: 'food/food-253.jpg',
		price: '2200',

	}, {
		name: 'sample Food 254',
		image: 'food/food-254.jpg',
		price: '2200',

	}, {
		name: 'sample Food 255',
		image: 'food/food-255.jpg',
		price: '2200',

	}, {
		name: 'sample Food 256',
		image: 'food/food-256.jpg',
		price: '2200',

	}, {
		name: 'sample Food 257',
		image: 'food/food-257.jpg',
		price: '2200',

	}, {
		name: 'sample Food 258',
		image: 'food/food-258.jpg',
		price: '2200',

	}, {
		name: 'sample Food 259',
		image: 'food/food-259.jpg',
		price: '2200',
	
	}, {
		name: 'sample Food 260',
		image: 'food/food-260.jpg',
		price: '2200',

	}, {
		name: 'sample Food 261',
		image: 'food/food-261.jpg',
		price: '2200',

	}, {
		name: 'sample Food 262',
		image: 'food/food-262.jpg',
		price: '2200',
		
	}, {
		name: 'sample Food 263',
		image: 'food/food-263.jpg',
		price: '2200',

	}, {
		name: 'sample Food 264',
		image: 'food/food-264.jpg',
		price: '2200',

	}, {
		name: 'sample Food 265',
		image: 'food/food-265.jpg',
		price: '2200',

	}, {
		name: 'sample Food 266',
		image: 'food/food-266.jpg',
		price: '2200',

	}, {
		name: 'sample Food 267',
		image: 'food/food-267.jpg',
		price: '2200',

	}, {
		name: 'sample Food 268',
		image: 'food/food-268.jpg',
		price: '2200',

	}, {
		name: 'sample Food 269',
		image: 'food/food-269.jpg',
		price: '2200',
	
	}, {
		name: 'sample Food 270',
		image: 'food/food-270.jpg',
		price: '2200',

	}, {
		name: 'sample Food 271',
		image: 'food/food-271.jpg',
		price: '2200',

	}, {
		name: 'sample Food 272',
		image: 'food/food-272.jpg',
		price: '2200',
		
	}, {
		name: 'sample Food 273',
		image: 'food/food-273.jpg',
		price: '2200',

	}, {
		name: 'sample Food 274',
		image: 'food/food-274.jpg',
		price: '2200',

	}, {
		name: 'sample Food 275',
		image: 'food/food-275.jpg',
		price: '2200',

	}, {
		name: 'sample Food 276',
		image: 'food/food-276.jpg',
		price: '2200',

	}, {
		name: 'sample Food 277',
		image: 'food/food-277.jpg',
		price: '2200',

	}, {
		name: 'sample Food 278',
		image: 'food/food-278.jpg',
		price: '2200',

	}, {
		name: 'sample Food 279',
		image: 'food/food-279.jpg',
		price: '2200',

	}, {
		name: 'sample Food 280',
		image: 'food/food-280.jpg',
		price: '2200',

	}, {
		name: 'sample Food 281',
		image: 'food/food-281.jpg',
		price: '2200',

	}, {
		name: 'sample Food 282',
		image: 'food/food-282.jpg',
		price: '2200',
		
	}, {
		name: 'sample Food 283',
		image: 'food/food-283.jpg',
		price: '2200',

	}, {
		name: 'sample Food 284',
		image: 'food/food-284.jpg',
		price: '2200',

	}, {
		name: 'sample Food 285',
		image: 'food/food-285.jpg',
		price: '2200',

	}, {
		name: 'sample Food 296',
		image: 'food/food-296.jpg',
		price: '2200',

	}, {
		name: 'sample Food 297',
		image: 'food/food-297.jpg',
		price: '2200',

	}, {
		name: 'sample Food 298',
		image: 'food/food-298.jpg',
		price: '2200',

	}, {
		name: 'sample Food 299',
		image: 'food/food-299.jpg',
		price: '2200',
	
	}, {
		name: 'sample Food 300',
		image: 'food/food-300.jpg',
		price: '2200',

	}, {
		name: 'sample Food 301',
		image: 'food/food-301.jpg',
		price: '2200',

	}, {
		name: 'sample Food 302',
		image: 'food/food-302.jpg',
		price: '2200',
		
	}, {
		name: 'sample Food 303',
		image: 'food/food-303.jpg',
		price: '2200',

	}, {
		name: 'sample Food 304',
		image: 'food/food-304.jpg',
		price: '2200',

	}, {
		name: 'sample Food 305',
		image: 'food/food-305.jpg',
		price: '2200',

	}, {
		name: 'sample Food 306',
		image: 'food/food-306.jpg',
		price: '2200',

	}, {
		name: 'sample Food 307',
		image: 'food/food-307.jpg',
		price: '2200',

	}, {
		name: 'sample Food 308',
		image: 'food/food-308.jpg',
		price: '2200',

	}, {
		name: 'sample Food 309',
		image: 'food/food-309.jpg',
		price: '2200',
	
	}, {
		name: 'sample Food 310',
		image: 'food/food-310.jpg',
		price: '2200',

	}, {
		name: 'sample Food 311',
		image: 'food/food-311.jpg',
		price: '2200',

	}, {
		name: 'sample Food 312',
		image: 'food/food-312.jpg',
		price: '2200',
		
	}, {
		name: 'sample Food 313',
		image: 'food/food-313.jpg',
		price: '2200',

	}, {
		name: 'sample Food 314',
		image: 'food/food-314.jpg',
		price: '2200',

	}, {
		name: 'sample Food 315',
		image: 'food/food-315.jpg',
		price: '2200',

	}, {
		name: 'sample Food 316',
		image: 'food/food-316.jpg',
		price: '2200',

	}, {
		name: 'sample Food 317',
		image: 'food/food-317.jpg',
		price: '2200',

	}, {
		name: 'sample Food 318',
		image: 'food/food-318.jpg',
		price: '2200',

	}, {
		name: 'sample Food 319',
		image: 'food/food-319.jpg',
		price: '2200',
	
	}, {
		name: 'sample Food 320',
		image: 'food/food-320.jpg',
		price: '2200',

	}, {
		name: 'sample Food 321',
		image: 'food/food-321.jpg',
		price: '2200',

	}, {
		name: 'sample Food 322',
		image: 'food/food-322.jpg',
		price: '2200',
		
	}, {
		name: 'sample Food 323',
		image: 'food/food-323.jpg',
		price: '2200',

	}, {
		name: 'sample Food 324',
		image: 'food/food-324.jpg',
		price: '2200',

	}, {
		name: 'sample Food 325',
		image: 'food/food-325.jpg',
		price: '2200',

	}, {
		name: 'sample Food 326',
		image: 'food/food-326.jpg',
		price: '2200',

	}, {
		name: 'sample Food 327',
		image: 'food/food-327.jpg',
		price: '2200',

	}, {
		name: 'sample Food 328',
		image: 'food/food-328.jpg',
		price: '2200',

	}, {
		name: 'sample Food 329',
		image: 'food/food-329.jpg',
		price: '2200',
	
	}, {
		name: 'sample Food 330',
		image: 'food/food-330.jpg',
		price: '2200',

	}, {
		name: 'sample Food 331',
		image: 'food/food-331.jpg',
		price: '2200',

	}, {
		name: 'sample Food 332',
		image: 'food/food-332.jpg',
		price: '2200',
		
	}, {
		name: 'sample Food 333',
		image: 'food/food-333.jpg',
		price: '2200',

	}, {
		name: 'sample Food 334',
		image: 'food/food-334.jpg',
		price: '2200',

	}, {
		name: 'sample Food 335',
		image: 'food/food-335.jpg',
		price: '2200',

	}, {
		name: 'sample Food 336',
		image: 'food/food-336.jpg',
		price: '2200',

	}, {
		name: 'sample Food 337',
		image: 'food/food-337.jpg',
		price: '2200',

	}, {
		name: 'sample Food 338',
		image: 'food/food-338.jpg',
		price: '2200',

	}, {
		name: 'sample Food 339',
		image: 'food/food-339.jpg',
		price: '2200',
	
	}, {
		name: 'sample Food 340',
		image: 'food/food-340.jpg',
		price: '2200',

	}, {
		name: 'sample Food 341',
		image: 'food/food-341.jpg',
		price: '2200',

	}, {
		name: 'sample Food 342',
		image: 'food/food-342.jpg',
		price: '2200',
		
	}, {
		name: 'sample Food 343',
		image: 'food/food-343.jpg',
		price: '2200',

	}, {
		name: 'sample Food 344',
		image: 'food/food-344.jpg',
		price: '2200',

	}, {
		name: 'sample Food 345',
		image: 'food/food-345.jpg',
		price: '2200',

	}, {
		name: 'sample Food 346',
		image: 'food/food-346.jpg',
		price: '2200',

	}, {
		name: 'sample Food 347',
		image: 'food/food-347.jpg',
		price: '2200',

	}, {
		name: 'sample Food 348',
		image: 'food/food-348.jpg',
		price: '2200',

	}, {
		name: 'sample Food 349',
		image: 'food/food-349.jpg',
		price: '2200',
	
	}, {
		name: 'sample Food 350',
		image: 'food/food-350.jpg',
		price: '2200',

	}, {
		name: 'sample Food 351',
		image: 'food/food-351.jpg',
		price: '2200',

	}, {
		name: 'sample Food 352',
		image: 'food/food-352.jpg',
		price: '2200',
		
	}, {
		name: 'sample Food 353',
		image: 'food/food-353.jpg',
		price: '2200',

	}, {
		name: 'sample Food 354',
		image: 'food/food-354.jpg',
		price: '2200',

	}, {
		name: 'sample Food 355',
		image: 'food/food-355.jpg',
		price: '2200',

	}, {
		name: 'sample Food 356',
		image: 'food/food-356.jpg',
		price: '2200',

	}, {
		name: 'sample Food 357',
		image: 'food/food-357.jpg',
		price: '2200',

	}, {
		name: 'sample Food 358',
		image: 'food/food-358.jpg',
		price: '2200',

	}, {
		name: 'sample Food 359',
		image: 'food/food-359.jpg',
		price: '2200',
	
	}, {
		name: 'sample Food 360',
		image: 'food/food-360.jpg',
		price: '2200',

	}, {
		name: 'sample Food 361',
		image: 'food/food-361.jpg',
		price: '2200',

	}, {
		name: 'sample Food 362',
		image: 'food/food-362.jpg',
		price: '2200',
		
	}, {
		name: 'sample Food 363',
		image: 'food/food-363.jpg',
		price: '2200',

	}, {
		name: 'sample Food 364',
		image: 'food/food-364.jpg',
		price: '2200',

	}, {
		name: 'sample Food 365',
		image: 'food/food-365.jpg',
		price: '2200',

	}, {
		name: 'sample Food 366',
		image: 'food/food-366.jpg',
		price: '2200',

	}, {
		name: 'sample Food 367',
		image: 'food/food-367.jpg',
		price: '2200',

	}, {
		name: 'sample Food 368',
		image: 'food/food-368.jpg',
		price: '2200',

	}, {
		name: 'sample Food 369',
		image: 'food/food-369.jpg',
		price: '2200',
	
	}, {
		name: 'sample Food 370',
		image: 'food/food-370.jpg',
		price: '2200',

	}, {
		name: 'sample Food 371',
		image: 'food/food-371.jpg',
		price: '2200',

	}, {
		name: 'sample Food 372',
		image: 'food/food-372.jpg',
		price: '2200',
		
	}, {
		name: 'sample Food 373',
		image: 'food/food-373.jpg',
		price: '2200',

	}, {
		name: 'sample Food 374',
		image: 'food/food-374.jpg',
		price: '2200',

	}, {
		name: 'sample Food 375',
		image: 'food/food-375.jpg',
		price: '2200',

	}, {
		name: 'sample Food 376',
		image: 'food/food-376.jpg',
		price: '2200',

	}, {
		name: 'sample Food 377',
		image: 'food/food-377.jpg',
		price: '2200',

	}, {
		name: 'sample Food 378',
		image: 'food/food-378.jpg',
		price: '2200',

	}, {
		name: 'sample Food 379',
		image: 'food/food-379.jpg',
		price: '2200',
	
	}, {
		name: 'sample Food 380',
		image: 'food/food-380.jpg',
		price: '2200',

	}, {
		name: 'sample Food 381',
		image: 'food/food-381.jpg',
		price: '2200',

	}, {
		name: 'sample Food 382',
		image: 'food/food-382.jpg',
		price: '2200',
		
	}, {
		name: 'sample Food 383',
		image: 'food/food-383.jpg',
		price: '2200',

	}, {
		name: 'sample Food 384',
		image: 'food/food-384.jpg',
		price: '2200',

	}, {
		name: 'sample Food 385',
		image: 'food/food-385.jpg',
		price: '2200',

	}
];