export const menu = [
	{
		name : 'sample Menu 1',
		image: 'menu/menu-1.jpg'
		
	}, {
		name: 'sample Menu 2',
		image: 'menu/menu-2.jpg'
		
		
	}, {
		name: 'sample Menu 3',
		image: 'menu/menu-3.jpg'
		

	}, {
		name: 'sample Menu 4',
		image: 'menu/menu-4.jpg'
		

	}, {
		name: 'sample Menu 5',
		image: 'menu/menu-5.jpg'
		

	}, {
		name: 'sample Menu 6',
		image: 'menu/menu-6.jpg'
		
	}, {
		name: 'sample Menu 7',
		image: 'menu/menu-7.jpg'
		
		
	}, {
		name: 'sample Menu 8',
		image: 'menu/menu-8.jpg'
		

	}, {
		name: 'sample Menu 9',
		image: 'menu/menu-9.jpg'
		

	}, {
		name: 'sample Menu 10',
		image: 'menu/menu-10.jpg'
		

	}, {
		name: 'sample Menu 11',
		image: 'menu/menu-11.jpg'
		
	}, {
		name: 'sample Menu 12',
		image: 'menu/menu-12.jpg'
		
		
	}, {
		name: 'sample Menu 13',
		image: 'menu/menu-13.jpg'
		

	}, {
		name: 'sample Menu 14',
		image: 'menu/menu-14.jpg'
		

	}, {
		name: 'sample Menu 15',
		image: 'menu/menu-15.jpg'
		

	}, {
		name: 'sample Menu 16',
		image: 'menu/menu-16.jpg'
		
	}, {
		name: 'sample Menu 17',
		image: 'menu/menu-17.jpg'
		
		
	}, {
		name: 'sample Menu 18',
		image: 'menu/menu-18.jpg'
		

	}, {
		name: 'sample Menu 19',
		image: 'menu/menu-19.jpg'
		

	}
];