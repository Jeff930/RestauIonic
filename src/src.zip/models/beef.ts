export const beefs = [
	{
		name : 'Kare-kare (Beef Peanut Stew)',
		description : 'Beef stew prepared with beef shank, oxtail and vegetables simmered in thick peanut sauce.',
		image: 'beef/BeefMechado.jpg',
		price : '14.99'
		
	},{
		name : 'Beef Kaldereta (Stew in Tomato Sauce/Liver)',
		description : 'Filipino stew made with beef, tomato sauce, potatoes, liver spread and cheese.',
		image: 'beef/BeefMechado.jpg',
		price : '13.99'
		
	},
	{
		name : 'Beef Mechado (Stew in Tomato Sauce)',
		description : 'Filipino beef stew with potatoes, carrots and onions.',
		image: 'beef/BeefMechado.jpg',
		price : '13.99'
		
	},{
		name : 'Beef Steak Tagalog',
		description : 'Thinly sliced beef sirloin sauteed in onions, lemon juice, soy sauce. Topped with fresh onion rings',
		image: 'beef/BeefSteakTagalog.jpg',
		price : '12.99'
		
	}
];