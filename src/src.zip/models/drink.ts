export const drinks = [
	{
		name : 'sample Drink 1',
		image: 'drinks/drink-1.jpg',
		price: '2200',
	}, {
		name: 'sample Drink 2',
		image: 'drinks/drink-2.jpg',
		price: '2200',
		
	}, {
		name: 'sample Drink 3',
		image: 'drinks/drink-3.jpg',
		price: '2200',

	}, {
		name: 'sample Drink 4',
		image: 'drinks/drink-4.jpg',
		price: '2200',

	}, {
		name: 'sample Drink 5',
		image: 'drinks/drink-5.jpg',
		price: '2200',

	}, {
		name: 'sample Drink 6',
		image: 'drinks/drink-6.jpg',
		price: '2200',

	}, {
		name: 'sample Drink 7',
		image: 'drinks/drink-7.jpg',
		price: '2200',

	}, {
		name: 'sample Drink 8',
		image: 'drinks/drink-8.jpg',
		price: '2200',

	}, {
		name: 'sample Drink 9',
		image: 'drinks/drink-9.jpg',
		price: '2200',

	}
];