export const appetizers = [
	{
		name : 'Lumpiang Shanghai (Egg Roll)',
		description : 'Deep-fried egg rolls consists of ground pork and veggies',
		image: 'appetizer/EggRolls.jpg',
		price : '7.99'
		
	}
	,{
		name : 'Vegetable Egg Rolls',
		description : 'Deep-fried vegetable(carrots, cabbage, green beans) egg rolls.',
		image: 'appetizer/EggRolls.jpg',
		price : '7.99'
		
	},{
		name : "Tokwa't Baboy (Fried Pork and Tofu)",
		description : 'Fried pork ruffle - Deep-fried tofu cubes and pork pieces with a dipping mixture of soy sauce, vinegar and chillies',
		image: 'appetizer/EggRolls.jpg',
		price : '7.99'
		
	},{
		name : 'Calamari',
		description : 'Squid rings that are battered and cooked deep-fried. Served with house special aioli dip.',
		image: 'appetizer/EggRolls.jpg',
		price : '8.99'
		
	},{
		name : 'French Fries',
		description : 'Deep-fried very thin, salted slices of potato.',
		image: 'appetizer/EggRolls.jpg',
		price : '7.99'
		
	},{
		name : 'Chicharon Bulaklak (Crispy Pork Ruffle)',
		description : 'Golden crisp pork ruffle fat served with a vinegar garlic dip.',
		image: 'appetizer/EggRolls.jpg',
		price : '8.99'
		
	}
];